import zipfile
import os

from pathlib import Path

def main():
    tpath = Path(r"../target")
    biggest = 0
    for files in os.listdir(tpath):
        for x in files:
            print(files)
            print(files[4]) 
            if (len(x) > 4 and int(x[4]) < biggest):
                biggest = int(x[4])

    zfile = zipfile.ZipFile(tpath / ("apb_%s.zip" % (biggest + 1)), "a")
    for file in os.listdir(r"./"):
        if file != "target":
            zfile.write(file, compress_type=zipfile.ZIP_DEFLATED)
    zfile.close()

if __name__ == "__main__":
    main()
